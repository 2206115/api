// src/sample.cpp
#include <iostream>

int add(int a, int b) {
    return a + b;
}

int multiply(int x, int y) {
    return x * y;
}
