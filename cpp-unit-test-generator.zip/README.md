# C++ Unit Test Generator using LLM

## 📦 Project Structure
```
cpp-unit-test-generator/
├── src/              # C++ source files
├── include/          # Header files
├── tests/            # Initial unit tests from LLM
├── output/           # Final refined unit tests
├── build_logs/       # Compiler logs
├── instructions/     # YAML files with LLM guidance
├── llm_prompts/      # Prompt templates for LLM interaction
```

## 🚀 How it Works

1. Send `sample.cpp` and `test_generation.yaml` to the LLM.
2. Generated tests go to `tests/`.
3. Use `refine_prompt.txt` with `refine_tests.yaml` to clean and optimize.
4. Build with Google Test and check logs in `build_logs/`.
5. Refined tests saved in `output/`.

## ✅ Requirements
- C++ Compiler (g++)
- Google Test framework
- Gcov / Lcov for test coverage
- Self-hosted LLM like Ollama or open GitHub models

## 📊 Test Coverage
Report to be filled after final test execution.

## ✍️ Author
[Your Name]

