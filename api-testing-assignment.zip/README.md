# API Server Testing Assignment

## 📌 API Overview
This API allows creating and retrieving users.

## 💻 Tech Stack
- Node.js
- Express.js
- MongoDB
- Jest (Testing)
- Supertest (API Testing)

## 🚀 Getting Started

### Install dependencies:
```bash
npm install
```

### Start the Server:
```bash
node src/server.js
```

### Run Tests:
```bash
npm test
```

## ✅ Test Coverage
Achieved: **72.4%**
Add your screenshot here: `coverage/coverage-summary.png`

## 🧪 Testing Tools
- Jest (Unit & Integration Tests)
- Supertest (API Testing)
- mongodb-memory-server (In-memory DB for testing)