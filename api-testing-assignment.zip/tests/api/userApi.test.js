const request = require('supertest');
const app = require('../../src/app');
const mongoose = require('mongoose');
const User = require('../../src/models/User');

beforeAll(async () => {
  await mongoose.connect('mongodb://localhost:27017/test-db', { useNewUrlParser: true, useUnifiedTopology: true });
});

afterAll(async () => {
  await mongoose.connection.db.dropDatabase();
  await mongoose.connection.close();
});

describe('POST /api/users', () => {
  it('should create a new user', async () => {
    const res = await request(app).post('/api/users').send({ name: 'Ritika', email: 'ritika@example.com' });
    expect(res.statusCode).toEqual(201);
    expect(res.body.name).toBe('Ritika');
  });
});